package com.example.user.shopmanagement;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateActivity extends AppCompatActivity {

    private EditText et_itemName;
    private EditText et_itemPrice;
    private String itemId, itemName, itemPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        itemId = getIntent ().getStringExtra ("itemId");
        itemName = getIntent ().getStringExtra ("itemName");
        itemPrice = getIntent ().getStringExtra ("itemPrice");

        et_itemName = findViewById (R.id.edit_itemName);
        et_itemPrice = findViewById (R.id.edit_itemPrice);

        et_itemName.setText (itemName);
        et_itemPrice.setText (itemPrice);

    }

    public void btn_update(View view) {

        DatabaseQuery databaseQuery = new DatabaseQuery(this);
        itemName=et_itemName.getText().toString();
        itemPrice=et_itemPrice.getText().toString();

        databaseQuery.updateItem(new User(itemId,itemName,itemPrice));

        Toast.makeText (this, "Updated Successfully", Toast.LENGTH_SHORT).show ();

    }

    public void btn_back(View view) {
        startActivity (new Intent(UpdateActivity.this, MainActivity.class));
    }
}
