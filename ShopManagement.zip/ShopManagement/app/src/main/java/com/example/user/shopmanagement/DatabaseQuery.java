package com.example.user.shopmanagement;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;
import java.util.ArrayList;

public class DatabaseQuery {

    private Context context;
    private DatabaseHelper dbhelper;

    public DatabaseQuery(Context context) {
        this.context = context;
        dbhelper = DatabaseHelper.getDBHelper (context);
    }

    public long insertData(User user) {
        long itemId = -1;
        SQLiteDatabase db = dbhelper.getWritableDatabase ();

        ContentValues contentValues = new ContentValues ();

        contentValues.put (DatabaseHelper.COLUMN_ITEMNAME, user.getItemName ());
        contentValues.put (DatabaseHelper.COLUMN_ITEMPRICE, user.getItemPrice ());
        itemId = db.insert (DatabaseHelper.TABLE_NAME, null, contentValues);

        if (itemId != -1) {
            Toast.makeText (context, "Data Inserted", Toast.LENGTH_SHORT).show ();
        } else {
            Toast.makeText (context, "Failed to insert", Toast.LENGTH_SHORT).show ();
        }
        return itemId;
    }

    public long getTotalItem() {
        SQLiteDatabase db = dbhelper.getReadableDatabase ();

        return DatabaseUtils.queryNumEntries (db, DatabaseHelper.TABLE_NAME);
    }
    public ArrayList<User> getAllData() {
        ArrayList<User> users = new ArrayList<> ();

        SQLiteDatabase db = dbhelper.getReadableDatabase ();

        String query = "SELECT * FROM " + DatabaseHelper.TABLE_NAME;

        Cursor cursor = db.rawQuery (query, null);

        if (cursor != null) {
            if (cursor.moveToFirst ()) {
                do {
                    String itemId = cursor.getString (cursor.getColumnIndex (DatabaseHelper.COLUMN_ITEMID));
                    String itemName = cursor.getString (cursor.getColumnIndex (DatabaseHelper.COLUMN_ITEMNAME));
                    String itemPrice = cursor.getString (cursor.getColumnIndex (DatabaseHelper.COLUMN_ITEMPRICE));
                    users.add (new User (itemId, itemName, itemPrice));
                }
                while (cursor.moveToNext ());
            }
        }

        return users;
    }public void updateItem(User user) {

        SQLiteDatabase db = dbhelper.getWritableDatabase ();
        ContentValues contentValues = new ContentValues ();

        contentValues.put (DatabaseHelper.COLUMN_ITEMNAME, user.getItemName ());
        contentValues.put (DatabaseHelper.COLUMN_ITEMPRICE, user.getItemPrice ());

        db.update (DatabaseHelper.TABLE_NAME, contentValues, DatabaseHelper.COLUMN_ITEMID + "=?", new String[]{user.getItemId ()});
    }

    public void deleteItem(String itemId) {
        SQLiteDatabase db = dbhelper.getWritableDatabase ();

        db.delete (DatabaseHelper.TABLE_NAME, DatabaseHelper.COLUMN_ITEMID + "=?", new String[]{itemId});


    }

}
