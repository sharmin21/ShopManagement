package com.example.user.shopmanagement;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText etItemName;
    private EditText etItemPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etItemName = findViewById (R.id.et_itemName);
        etItemPrice = findViewById (R.id.et_itemPrice);
    }

    public void btn_submit(View view) {

            String itemName = etItemName.getText ().toString ();
            String itemPrice = etItemPrice.getText ().toString ();

            DatabaseQuery dbQuery = new DatabaseQuery (MainActivity.this);

            long itemId = dbQuery.insertData (new User (itemName, itemPrice));

            Toast.makeText (this, "" + dbQuery.getTotalItem (), Toast.LENGTH_SHORT).show ();

            startActivity (new Intent(MainActivity.this, ListActivity.class));
    }

}
