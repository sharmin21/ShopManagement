package com.example.user.shopmanagement;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

public class ListActivity extends AppCompatActivity {

private RecyclerView recyclerView;
private UserAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        recyclerView = findViewById (R.id.recyclerView);
        DatabaseQuery dbQuery = new DatabaseQuery (this);
        adapter = new UserAdapter (this, dbQuery.getAllData ());
        recyclerView.setAdapter (adapter);
        recyclerView.setLayoutManager (new LinearLayoutManager (this));

    }

    public void btn_add(View view) {
        startActivity (new Intent(ListActivity.this, MainActivity.class));

    }
}
