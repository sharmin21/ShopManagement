package com.example.user.shopmanagement;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {

    private Context context;
    private ArrayList<User> users;

    public UserAdapter(Context context, ArrayList<User> users) {
        this.context = context;
        this.users = users;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from (context).inflate (R.layout.list_item, parent, false);
        return new UserViewHolder (view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder,final int position) {
        holder.tv_itemName.setText (users.get (position).getItemName ());
        holder.tv_itmePrice.setText (users.get (position).getItemPrice ());
        holder.btDelete.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                DatabaseQuery dbquery = new DatabaseQuery (context);
                dbquery.deleteItem (users.get (position).getItemId());
                RecyclerView recyclerView = ((Activity) context).findViewById (R.id.recyclerView);
                DatabaseQuery databaseQuery = new DatabaseQuery (context);
                ArrayList<User> users = databaseQuery.getAllData ();
                UserAdapter adapter = new UserAdapter (context, users);

                recyclerView.setAdapter (adapter);
                recyclerView.setLayoutManager (new LinearLayoutManager(context));
            }});
        holder.btEdit.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (context, UpdateActivity.class);
                intent.putExtra ("itemId", users.get (position).getItemId());
                intent.putExtra ("itemName", users.get (position).getItemName ());
                intent.putExtra ("itemPrice", users.get (position).getItemPrice ());
                context.startActivity (intent);
                ((Activity) context).finish ();
            }
        });
    }

    @Override
    public int getItemCount() {
        return users.size ();
    }

    public class UserViewHolder extends RecyclerView.ViewHolder {
        public TextView tv_itemName;
        public TextView tv_itmePrice;
        public Button btDelete;
        public Button btEdit;

        public UserViewHolder(View itemView) {
            super (itemView);
            tv_itemName = itemView.findViewById (R.id.tv_itemName);
            tv_itmePrice = itemView.findViewById (R.id.tv_itmePrice);
            btDelete = itemView.findViewById (R.id.bt_delete);
            btEdit = itemView.findViewById (R.id.bt_edit);
        }
    }
}
