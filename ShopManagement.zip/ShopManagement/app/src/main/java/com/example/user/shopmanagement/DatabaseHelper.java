package com.example.user.shopmanagement;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "productList";
    public static final int DATABASE_VERSION = 1;

    public static final String TABLE_NAME = "product";
    public static final String COLUMN_ITEMID = "_itemId";
    public static final String COLUMN_ITEMNAME = "itemName";
    public static final String COLUMN_ITEMPRICE = "itemPrice";

    private static DatabaseHelper databaseHelper = null;

    public DatabaseHelper(Context context) {
        super (context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static DatabaseHelper getDBHelper(Context context) {
        if (databaseHelper == null) {
            databaseHelper = new DatabaseHelper (context);
        }
        return databaseHelper;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_STUDENT_TABLE = "CREATE TABLE " + TABLE_NAME + " ( " +
                COLUMN_ITEMID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_ITEMNAME + " TEXT NOT NULL," +
                COLUMN_ITEMPRICE + " TEXT NOT NULL)";

        db.execSQL (CREATE_STUDENT_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL ("DROP TABLE IF EXISTS " + TABLE_NAME);

            onCreate (db);

        }
}
